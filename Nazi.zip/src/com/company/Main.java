package com.company;


import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import java.io.File;
import java.util.ArrayList;

public class Main {

    private static Treenode root;
    private static class Treenode {

        private ArrayList<String> times;

        private String name;

        public Treenode(String data){
            this.name=data;
        }
    }

    private String inputFile;
    private static String[] rowsData;

    public void setInputFile(String inputFile){
        this.inputFile = inputFile;
    }

    public void read(){
        File inputWorkBook = new File(inputFile);
        Workbook w;

        try{
            w = Workbook.getWorkbook(inputWorkBook);
            Sheet sheet = w.getSheet(0);

            int index = 0;
            rowsData = new String[sheet.getRows()];
            for(int i = 1; i < sheet.getRows(); i++){
                String str = "";
                for(int j = 0; j < sheet.getColumns(); j++){
                    Cell cell = sheet.getCell(j , i);
                    if(j < 1){
                        str += cell.getContents();
                    }else{
                        str += ';' + cell.getContents();
                    }
                }
                rowsData[index++] = str;
                //System.out.println(str);
            }


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static boolean checkIfExists(String stringToLocate) {
        return stringToLocate.equals("CSE499A/EEE499A/ETE499A") || stringToLocate.equals("CSE499B/EEE499B/ETE499B");
    }


    //Generate Combinations
    private static void generateCombinations(Treenode treenode, Treenode[] treenodes){
        ArrayList<String> combinations = new ArrayList<String>();

        String[] times1 = new String[treenode.times.size()];
        times1 = treenode.times.toArray(times1);
        for (String time1 :
                times1) {
            for(int i = 0; i < treenodes.length; i++){
                if(!treenodes[i].name.equals(treenode.name)){
                    String[] times2 = new String[treenodes[i].times.size()];
                    times2 = treenodes[i].times.toArray(times2);
                    for (String time2 :
                            times2){
                        if(!time1.equals(time2)){
                            combinations.add(treenode.name +" "+ time1 + " & "+treenodes[i].name
                            +" "+time2);
                        }
                    }
                }
            }
        }

        for(int i = 0; i < combinations.size(); i++){
            System.out.println(combinations.get(i));
        }

    }

    public static void main(String[] args) throws Exception {
        Main test = new Main();
        test.setInputFile("nsu subjects.xls");
        test.read();

        String[] uniqueNodes = new String[1500];
        int c = 0;

        //Cse499A,cse498R related Informations
        for(int i = 0; rowsData[i] != null; i++){
            String[] parseString = rowsData[i].split(";");
            if(!parseString[3].equals("TBA")){
                boolean found = checkIfExists(parseString[0]);
                if(found){
                    uniqueNodes[c++] = rowsData[i];
                }
            }
        }

        //Set nodes based on taken courses
        Treenode[] treenodes = new Treenode[2];
        treenodes[0] = new Treenode("CSE499A/EEE499A/ETE499A");
        treenodes[1] = new Treenode("CSE499B/EEE499B/ETE499B");
        treenodes[0].times = new ArrayList<String>();
        treenodes[1].times = new ArrayList<String>();


        //Find all the unique name cousrse as node and insert their times in it.
        for(int i = 0; i < c; i++){
            //System.out.println(uniqueNodes[i]);

            String[] parseString = uniqueNodes[i].split(";");

            //System.out.println(parseString[3]);

            for(int j = 0; j < treenodes.length; j++){
                if(treenodes[j].name.equals(parseString[0])){
                    treenodes[j].times.add(parseString[3]);
                }
            }
        }

        generateCombinations(treenodes[0], treenodes);









    }
}
